<?php 

$conn= new mysqli('localhost','ninjatox__vey','[%vp[1ov6E_=','ninjatox_vey')or die("Could not connect to mysql".mysqli_error($con));
