-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 25, 2022 at 03:39 PM
-- Server version: 5.7.39
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ninjatox_surveyish`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(30) NOT NULL,
  `survey_id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `answer` text NOT NULL,
  `question_id` int(30) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `survey_id`, `user_id`, `answer`, `question_id`, `date_created`) VALUES
(7, 8, 21, 'John Doe', 5, '2022-07-26 11:22:12'),
(8, 8, 21, 'Ytbrw', 6, '2022-07-26 11:22:12'),
(9, 9, 25, '[QHrLm]', 7, '2022-08-04 07:29:30'),
(10, 9, 25, '[tjNnR]', 8, '2022-08-04 07:29:30'),
(11, 9, 25, '[WpFtM]', 9, '2022-08-04 07:29:30'),
(12, 9, 25, '', 10, '2022-08-04 07:29:30'),
(13, 9, 25, '[YULBn]', 11, '2022-08-04 07:29:30'),
(14, 9, 25, 'Every time I touch a surface that is unclean ', 12, '2022-08-04 07:29:30'),
(15, 9, 25, 'Weekly', 13, '2022-08-04 07:29:30');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(30) NOT NULL,
  `question` text NOT NULL,
  `frm_option` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `order_by` int(11) NOT NULL,
  `survey_id` int(30) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `frm_option`, `type`, `order_by`, `survey_id`, `date_created`) VALUES
(5, 'What is your name?', '', 'textfield_s', 0, 8, '2022-07-26 11:18:08'),
(6, 'What is your gender?', '{\"Ytbrw\":\"Male\",\"gqXas\":\"Female\"}', 'radio_opt', 0, 8, '2022-07-26 11:19:06'),
(7, 'What do you think about the cleanliness in your vicinty?', '{\"QHrLm\":\"Very good\",\"wTsBh\":\"Good\",\"oqjlb\":\"Moderate\",\"KMQFz\":\"Bad\",\"fnGWt\":\"Very Bad \"}', 'check_opt', 0, 9, '2022-08-04 06:32:24'),
(8, 'What do you do with leftover trash after cleaning the house?', '{\"tjNnR\":\"Keep them in a dust bin\",\"PTwkh\":\"Keep it in the garden\",\"QjzFU\":\"Throw it outside the house\"}', 'check_opt', 0, 9, '2022-08-04 06:55:18'),
(9, 'How many times in a week is your bins picked up?', '{\"cZFfl\":\"Daily\",\"WpFtM\":\"Weekly\",\"pceAB\":\"Alternate days\",\"QNnJD\":\"Twice in a week\"}', 'check_opt', 0, 9, '2022-08-04 06:57:56'),
(10, 'How are the waste materials collected?', '', 'textfield_s', 0, 9, '2022-08-04 07:00:21'),
(11, 'What form of drinking water do you use?', '{\"yPDZK\":\"Treated water\",\"YULBn\":\"Filtered water\",\"IHqzR\":\"Boiled water\",\"HghpP\":\"Original form\"}', 'check_opt', 0, 9, '2022-08-04 07:02:37'),
(12, 'How often do you wash your hand daily?', '', 'textfield_s', 0, 9, '2022-08-04 07:07:04'),
(13, 'How often do you cut your nails?', '', 'textfield_s', 0, 9, '2022-08-04 07:12:41');

-- --------------------------------------------------------

--
-- Table structure for table `survey_set`
--

CREATE TABLE `survey_set` (
  `id` int(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `user_id` int(30) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `survey_set`
--

INSERT INTO `survey_set` (`id`, `title`, `description`, `user_id`, `start_date`, `end_date`, `date_created`) VALUES
(9, 'A HEALTHY LIFE REQUIRES CLEANLINESS AND GOOD HYGIENE', 'To promote health, one must practise proper personal cleanliness. Personal hygiene practises like hand washing and tooth brushing  and flossing help to protect against bacteria, viruses and disease. Maintaining good physical hygiene is beneficial for your mental health, since it makes you feel good about yourself.  ', 0, '2022-08-04', '2022-09-30', '2022-08-04 06:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `middlename` varchar(200) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '3' COMMENT '1=Admin,2 = Staff, 3= Subscriber',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `middlename`, `contact`, `address`, `email`, `password`, `type`, `date_created`) VALUES
(1, 'Admin', 'Admin', '', '+123456789', 'Sample address', 'admin@surveyish.com', '0192023a7bbd73250516f069df18b500', 1, '2022-11-10 08:43:06'),
(13, 'Salem oghenemine', 'Edemivwaye', ' ', '0', 'Sample', '62dfd09d6b57c@inspire-survey.com', '4518ff86e17cedb1529f1029fe7b71e2', 3, '2022-07-26 07:31:41'),
(16, 'Oluwakemi Olaide', 'Egungbohun', ' ', '0', 'Sample', '62dfdf591ee42@inspire-survey.com', '159757c1d8e963e09d7d6316b96ac96b', 3, '2022-07-26 08:34:33'),
(17, 'Oluwakemi Olaide', 'Egungbohun', ' ', '0', 'Sample', '62dfdf641c611@inspire-survey.com', '979d779ac17a3f472534b33a1e9fb956', 3, '2022-07-26 08:34:44'),
(18, 'Oluwakemi Olaide', 'Egungbohun', ' ', '0', 'Sample', '62dfdf5f4ba72@inspire-survey.com', 'c2cdc1340069039a52a8e1c7d47dd963', 3, '2022-07-26 08:34:39'),
(21, 'John', 'Doe', ' ', '0', 'Sample', '62e0068d0828d@inspire-survey.com', 'd9fcf16c7fdd169481f5afde0bb91230', 3, '2022-07-26 11:21:49'),
(25, 'Salem', 'Edemivwaye', ' ', '0', 'Sample', '62ebacfa6c8a0@inspire-survey.com', 'f5c11112f49449a854648de52a72f4ce', 3, '2022-08-04 07:26:50'),
(26, 'Choice', 'Abada', ' ', '0', 'Sample', '62ec3648c8428@inspire-survey.com', '156d4f6c31ff0050ffe4d0a7cb3f496b', 3, '2022-08-04 17:12:40'),
(27, 'femi', '', ' ', '0', 'Sample', '62eeab0400046@inspire-survey.com', 'fecfad613f873ad7ed542ca6419cd709', 3, '2022-08-06 13:55:16'),
(28, 'Admin', '', ' ', '0', 'Sample', '62f349377a569@inspire-survey.com', '89f0351c20ed823f7b21204fff111669', 3, '2022-08-10 01:59:19'),
(29, 'choice', '', ' ', '0', 'Sample', '62f37d4b38209@inspire-survey.com', '0c5d34e31d4b3631b99f941c2d1ff070', 3, '2022-08-10 05:41:31'),
(30, 'Choice', '', ' ', '0', 'Sample', '62f38b2b2dbd7@inspire-survey.com', '4ece70da365469e6fcf87276332d90a3', 3, '2022-08-10 06:40:43'),
(38, 'Choice', 'Abada', '', '4636473483', '8 TYNDALE PLACE', 'choiceabada@gmail.com', 'af97ad328dd4a95c02fad69ea0d2ac29', 3, '2022-08-14 13:00:33'),
(39, 'Testing', 'Account', '.', '0099000090', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua.', '3kzge91wb@mozmail.com', '92465b0e81c0d45124f559c98b28d8ff', 3, '2022-08-16 10:05:57'),
(40, 'gfg', 'gg', 'ggfg', 'ggg', 'gg', '123456@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 3, '2022-08-16 10:15:24'),
(41, 'Choice', 'Abada', '', '63737373883', '8 Tyndale Place\r\nWheatley', 'frankbinney19995@gmail.com', '6217f61721a5af2937b58b712000de8c', 3, '2022-08-18 16:22:02'),
(42, 'James', 'Gin ', '', 'Gdgshd', 'Gsvsbsbsbbs', 'jamesgin@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 3, '2022-08-18 16:25:45'),
(43, 'Oluwakemi ', 'Egungbohun ', 'Olaide', '07342309928', '11 Nuffield road headington oxford', 'oluwakemmy39@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 3, '2022-08-19 13:08:52'),
(44, 'Choice', 'Abada', '', 'Ffg', '8 Tyndale Place\r\nWheatley', 'givemeas@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 3, '2022-08-21 13:34:05'),
(45, 'Dog', 'cheese', '', '1234', 'E', 'mgreen@brookes.ac.uk', 'dede214c2e9ad6d11b1f041efee304b9', 3, '2022-08-23 11:07:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey_set`
--
ALTER TABLE `survey_set`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `survey_set`
--
ALTER TABLE `survey_set`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
