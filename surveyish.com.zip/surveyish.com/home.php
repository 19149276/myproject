<style type="text/css">
  .info-card{
      box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2);
  border-radius: .25rem;
  background-color: #fff; 
  margin-bottom: 1rem;
  min-height: 80px;
  padding: .5rem; 
  width: 100%;
  text-align: center;
}
.info-icon{
  font-size: 80px;
}
.info-number{
  font-size: 25px;
font-weight: bold;
}
</style>
<?php include('db_connect.php') ?>
<!-- Info boxes -->
<?php if($_SESSION['login_type'] == 1): ?>
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-card">
              <span class="info-icon text-primary"><i class="fas fa-users"></i></span>

              <div class="info-content">
                <span class="info-number">
                 <?php echo $conn->query("SELECT * FROM users where type = 3")->num_rows; ?>
                </span><br>
                <span class="info-box-text">Total Subscribers</span>
                
              </div>
              <!-- /.info-box-content -->
            </div>

            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-card">
              <span class="info-icon text-primary"><i class="fas fa-poll-h"></i></span>

              <div class="info-content">
                <span class="info-number">
                  <?php echo $conn->query("SELECT * FROM survey_set")->num_rows; ?>
                </span><br>
                <span class="info-box-text">Total Surveys</span>
                
              </div>
              <!-- /.info-box-content -->
            </div> 
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
      </div>

<?php else: ?>
	 <div class="col-12">
          <div class="card">
          	<div class="card-body">
          		Welcome <?php echo $_SESSION['login_name'] ?>!
          	</div>
          </div>
      </div>
      <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-card">
              <span class="info-icon text-primary"><i class="fas fa-poll-h"></i></span>

              <div class="info-content">
                <span class="info-number">
                  <?php echo $conn->query("SELECT distinct(survey_id) FROM answers  where user_id = {$_SESSION['login_id']}")->num_rows; ?>
                </span><br>
                <span class="info-box-text">Total Surveys Taken</span>
                
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
      </div>
          
<?php endif; ?>
