<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include('./db_connect.php');


if(!isset($_SESSION['first_visit'])){
    $_SESSION['first_visit'] = 1;
    ?>
    <script>
        location.href = "welcome.php";
    </script>
    <?php
}
?>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Login | Online Survey System</title>
 	

<?php include('./header.php'); ?>
<?php 
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

?>
<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    position: fixed;
	    top:0;
	    left: 0;
	    overflow:scroll;
	    /*background: #007bff;*/
	}
	main#main{
		width:100%;
		height: calc(100%);
		display: flex;
	}
	h4{
		text-transform: uppercase;
letter-spacing: 17px;
text-shadow: 0px 0px 5px #02392B;
	}
/*html{*/
/*    overflow:scroll;*/
/*}*/
</style>

<body class="">

<section class="ftco-section">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-md-6 text-center mb-5"> 
						<h2 class="heading-section">Online Survey</h2>
						</div>
					</div>
					<div class="row justify-content-center">
						<div class="col-md-12 col-lg-10">
							<div class="wrap d-md-flex">
								<div class="img" style="background-image:url(assets/img/bg2.jpg)">
								</div>
								<div class="login-wrap p-4 p-md-5">
									<div class="d-flex">
										<div class="w-100">
											<h3 class="mb-4">Sign In</h3>
										</div>
										
									</div>
									<form class="signin-form" id="login-form">
										<div class="form-group mb-3">
			  							<label for="email" class="control-label text-dark">Email</label>
			  							<input type="text" id="email" name="email" class="form-control form-control-sm" placeholder="Email">
			  						</div>
			  						<div class="form-group mb-3">
			  							<label for="password" class="control-label text-dark">Password</label>
			  							<input type="password" id="password" name="password" class="form-control form-control-sm" placeholder="password">
			  						</div>
										<div class="form-group">
											<button class="form-control btn btn-primary rounded submit px-3">Sign In</button>
										</div> 
									</form>

									<p class="text-center">Not a member? <a data-toggle="tab" href="register.php">Sign Up</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
 <!--  <main id="main" >
  	
  		<div class="align-self-center w-100">
		<h4 class="text-white text-center"><b>Online Survey</b></h4>
  		<div id="login-center" class="row justify-content-center">
  			<div class="card col-md-4">
  				<div class="card-body">
  					<form id="login-form" >
  						<div class="form-group">
  							<label for="email" class="control-label text-dark">Email</label>
  							<input type="text" id="email" name="email" class="form-control form-control-sm">
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label text-dark">Password</label>
  							<input type="password" id="password" name="password" class="form-control form-control-sm">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
  		</div>
  </main> --> 


</body>
<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				if(resp == 1){
					location.href ='index.php?page=survey_widget';
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
	$('.number').on('input',function(){
        var val = $(this).val()
        val = val.replace(/[^0-9 \,]/, '');
        $(this).val(val)
    })
</script>	
</html>